import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: './login.component.html',
    styleUrls: ['./login.css']
})
export class LoginComponent implements OnInit {
    constructor() { }

    ngOnInit(): void { }
}
